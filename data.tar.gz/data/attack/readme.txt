### Sleipnir Dataset:


This directory contains the dataset for the `attack` track for the Robust Malware Detection Challenge @ ADVML-KDD'19

### Description
The dataset contains of the binary feature vectors extracted from benign and malicious portable executables (PEs) saved in the `benign` and `malicious` directories repectively.

For the purpose of this challenge, no benign data points will be used (hence its folder it empty; please do not remove it as its required for compatibility reasons). With this downloaded dataset, make sure you edit the `parameters.ini` file in the challenge kit code to reflect the paths to the `bengin` and `malicious` directories as follows. There are 3800 files in the `malicious` directory.

```
benign_filepath = "PATH TO THE DIR OF THIS FILE"/bengin/
malicious_filepath = "PATH TO THE DIR OF THIS FILE"/malicious/
num_files_to_use = 3800
```
and set the flag
```
use_saved_feature_vectors = True
```

Note: the feature vectors are stored with their corresponding PE names for ease of indexing. For example (after downloading the required packages and setting the python environment `nn_mal` as defined the repo above), we have:

```
$ cd benign/
$ source activate nn_mal
>>> import pickle
>>> import torch
>>> pickle.load(open('ZZPhoto.exe', 'rb')) # ZZPhoto.exe is a pickle file not an executable

    1     0     0  ...      0     0     0
[torch.FloatTensor of size 1x22761]
```

### Crafting Transferable Adversarial Examples:

For this challenge, you're required to send us a numpy array of 3800x2276 of zeros and ones that represents the crafted transferable adversarial examples of the files in `malicious`. To this end, do the following:

1. Ensure the `parameters.ini` file of the challenge's code has the following parameter setup.

```
[challenge]
eval = False
attack = True
defend = False
adv_examples_path = "PATH TO WHERE THE NUMPY ARRAY WILL BE STORED"
```

2. Edit the `process_adv_examples` function in the `framework.py` file of the challenge's code at LINE 312 to craft adversarial examples `x_adv`. Participants are free to craft their own inner maximizers or use any other model than the baseline model provided ``. If you're training your own model, enusre the relevant parameters in `parameters.ini` are updated accordingly, namely:

```
load_model_weights = True # set it to True if you're loading the model from its file (this is the default setup), `False` will result in initializing the model with random weights
model_weights_path = "PATH TO THE MODEL FILE" # by default this is set to the shared baseline model file, you may change it to any model you have trained.
```
you can also change the name of the trained model and evasion attack to reflect your implementation.
```
training_method = natural
evasion_method = natural
```

3. Run the `framework.py` file

4. A `.npy` file will be stored in the `adv_examples_path`. Send this file to us.


### Evaluation

We will evaluate our secret model against the adversarial examples and report the evasion rate.


### Relevant Papers:

1. Al-Dujaili, Abdullah, Alex Huang, Erik Hemberg, and Una-May O'Reilly. "Adversarial Deep Learning for Robust Detection of Binary Encoded Malware." arXiv preprint arXiv:1801.02950 (2018).

2. Huang, Alex, Abdullah Al-Dujaili, Erik Hemberg, and Una-May O'Reilly. "On Visual Hallmarks of Robustness to Adversarial Malware." arXiv preprint arXiv:1805.03553 (2018).


### Citations

If you make use of this code and you'd like to cite us, please consider the following:

@article{al2018adversarial,
  title={Adversarial Deep Learning for Robust Detection of Binary Encoded Malware},
  author={Al-Dujaili, Abdullah and Huang, Alex and Hemberg, Erik and O'Reilly, Una-May},
  journal={arXiv preprint arXiv:1801.02950},
  year={2018}
}


