### Sleipnir Dataset:


This directory contains the dataset for the `defend` track for the Robust Malware Detection Challenge @ ADVML-KDD'19

### Description
The dataset contains of the binary feature vectors extracted from benign and malicious portable executables (PEs) saved in the `benign` and `malicious` directories repectively.

For the purpose of this challenge, there are 15,200 malicious and 15,200 benign files. Based on this dataset, the task is to build a robust malware detector. The following is an illustration of the dataset and the code kit that you may find helpful.

Setup: With this downloaded dataset, make sure you edit the `parameters.ini` file in the kit's code to reflect the paths to the `bengin` and `malicious` directories as follows

```
benign_filepath = "PATH TO THE DIR OF THIS FILE"/bengin/
malicious_filepath = "PATH TO THE DIR OF THIS FILE"/malicious/
num_files_to_use = 15200
```
and set the flag
```
use_saved_feature_vectors = True
```

Note: the feature vectors are stored with their corresponding PE names for ease of indexing. For example (after downloading the required packages and setting the python environment `nn_mal` as defined the repo above), we have:

```
$ cd benign/
$ source activate nn_mal
>>> import pickle
>>> import torch
>>> pickle.load(open('ZZPhoto.exe', 'rb')) # ZZPhoto.exe is a pickle file not an executable

    1     0     0  ...      0     0     0
[torch.FloatTensor of size 1x22761]
```

### Building Robust Models Challenge

For this challenge, you're required to send us a '.pt' file of your robust model. To this end, do the following:

1. Ensure the `parameters.ini` file of the challenge's code has the following parameter setup.

```
[challenge]
eval = False
attack = False
defend = True
adv_examples_path = "NOT NEEDED FOR THIS TRACK"
```

2. Edit the `framework.py` file of the challenge's code to produce a robust model. Participants are free to craft their own inner maximizers, develop their own training method, or change the model architecture. The `framework.py` implements an adversarial training framework based on [1]. It also implements supporting code for the `attack` track.

A good place to start is at LINE 386 of the `framework.py`. This block of code runs multiple epochs fitting the model using a minmax formulation (specified by the `training_method` parameter in the `parameters.ini` file) and reports the performance on a validation set. It also reports the performance on a test set and evaluates its robustness against an attack/inner maximizer (specified by the `evasion_method` parameter in the `parameters.ini` file)

- To change the model architecture, you can change the `nets/ff_classifier.py` or add a new similar model and ensure it is being called by the `framework.py`.
- To change/add a new inner maximizer, refer to the `inner_maximizers/inner_maximizers.py`. It implements all the method that can be used as a `training_method` or `evasion_method`
- To change the training framework, edit the code block of LINE 386

We are providing a baseline model that you can load and run the code with. When you're training your own model, enusre the relevant parameters in `parameters.ini` are updated accordingly, namely:

```
train_model_from_scratch = False # set it to True if you're training your own model which will be used later to craft the adv examples.
load_model_weights = True # set it to True if you're loading the model from its file (this is the default setup)
model_weights_path = "PATH TO THE MODEL FILE" # by default this is set to the shared baseline model file
```

you can also change the name of the trained model and evasion attack to reflect your implementation.

```
training_method = natural
evasion_method = natural
```

Note: In the code block of LINE 386, `bscn.ratio()` is used to track how many distinct samples are introduced in the training setup. This is a metric from [1] and you can ignore it.

3. Run the `framework.py` file.

Note: To see how the model is doing, you can either follow the stdout messages or refer to the results json file generated at `./results_files` at the end of training.

4. A `.pt` file will be stored in the `./helper_files/` folder. Send this file to us.


### Evaluation

We will evaluate the model against a set of adversaries on a holdout set and report the F1 score based on the worst adversary.


### Relevant Papers:

1. Al-Dujaili, Abdullah, Alex Huang, Erik Hemberg, and Una-May O'Reilly. "Adversarial Deep Learning for Robust Detection of Binary Encoded Malware." arXiv preprint arXiv:1801.02950 (2018).

2. Huang, Alex, Abdullah Al-Dujaili, Erik Hemberg, and Una-May O'Reilly. "On Visual Hallmarks of Robustness to Adversarial Malware." arXiv preprint arXiv:1805.03553 (2018).


### Citations

If you make use of this code and you'd like to cite us, please consider the following:

@article{al2018adversarial,
  title={Adversarial Deep Learning for Robust Detection of Binary Encoded Malware},
  author={Al-Dujaili, Abdullah and Huang, Alex and Hemberg, Erik and O'Reilly, Una-May},
  journal={arXiv preprint arXiv:1801.02950},
  year={2018}
}
